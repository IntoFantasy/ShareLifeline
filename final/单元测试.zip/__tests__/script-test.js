jest.useFakeTimers()
jest.spyOn(global, 'setTimeout');
test('settimeout should be called only once', () => {
  let callback1 = jest.fn();
  let callback2 = jest.fn();
  const widthchanger = require('../script');
  widthchanger(100,callback1,callback2);
  //jest.runAllTimers();
  expect(setTimeout).toHaveBeenCalledTimes(1);
  expect(callback1).toHaveBeenCalledTimes(0);
  expect(callback2).toHaveBeenCalledTimes(0);
  //the real timers are hung up.
});
test('width should be correctly modified', () => {
  let callback1 = jest.fn();
  let callback2 = jest.fn();
  const widthchanger = require('../script');
  widthchanger(100,callback1,callback2);
  jest.runAllTimers();
  //expect(setTimeout).toHaveBeenCalledTimes(1);
  expect(callback1).toHaveBeenCalledTimes(102);
  //callback1 should be called 2050/20=102 times
  expect(callback2).toHaveBeenCalledTimes(1);
  //callback2 should be called just 1 time,which means width has been correctly changed.
});

test('search page should return successfully',() => {
  const search = require('../search');
  url = search('123');
  expect(url).toBe('/searchResult?searchContent=123');
});