function widthchanger(width,callback1,callback2){
    
let slide = setInterval(() => {
    width -= 1;
    callback1&&callback1();
}, 20)

setTimeout(() => {
    clearInterval(slide);
    width = `100%`;
    callback2&&callback2();
}, 2050);
}
module.exports=widthchanger;